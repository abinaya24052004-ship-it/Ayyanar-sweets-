# Ayyanar Sweets App — Ready-to-build project

இந்த ZIP-ல் Android app source + website/PWA files + GitHub Actions APK build workflow உள்ளது.

## APK உருவாக்குவது (phone-ல் GitHub பயன்படுத்தலாம்)
1. ZIP-ஐ extract செய்யுங்கள்.
2. GitHub-ல் புதிய repository உருவாக்குங்கள் (உதா: `ayyanar-sweets-app`).
3. இந்த project-ல் உள்ள கோப்புகள்/கோப்புறைகளை repository-ன் root-ல் upload செய்யுங்கள். `.github` folder-ஐயும் upload செய்ய வேண்டும்.
4. GitHub repository → **Actions** → **Build Ayyanar Sweets Android APK** → **Run workflow**.
5. Build முடிந்ததும் workflow run-ஐத் திறந்து **Artifacts** பகுதியில் `Ayyanar-Sweets-debug-apk` download செய்யுங்கள்.
6. ZIP-ஐ extract செய்து `app-debug.apk`-ஐ Android phone-ல் install செய்யுங்கள். Android கேட்கும் போது browser/file manager-க்கு “Install unknown apps” அனுமதி கொடுக்க வேண்டியிருக்கலாம்.

## கடை விவரங்களை மாற்றுவது
- `android/app/src/main/assets/products.js` மற்றும் `web/products.js`: product பெயர், விலை, pack details.
- `android/app/src/main/assets/script.js` மற்றும் `web/script.js`: `WHATSAPP_NUMBER = "91XXXXXXXXXX"` என்பதை உங்கள் WhatsApp number-ஆக மாற்றவும் (country code உடன் digits மட்டும்).
- Product photos தற்போது placeholder emoji. உண்மையான Ayyanar Sweets photos/logo சேர்க்க வேண்டுமெனில் assets-ல் படங்களை வைத்து UI-யை மாற்ற வேண்டும்.

## நேர்மையான நிலை
இந்த project APK-ஐ GitHub Actions மூலம் build செய்யத் தயாராக உள்ளது; ஆனால் இந்த ZIP மட்டும் APK அல்ல. Build செய்ய உங்கள் GitHub account-ல் upload/run செய்ய வேண்டும். WhatsApp number, real product images, final prices, delivery rules ஆகியவை இன்னும் shop-specific ஆக நிரப்பப்படவில்லை. Payment gateway, online order database, admin dashboard இங்கு இல்லை.
