// Replace product names/prices/pack sizes with the current shop catalogue.
const PRODUCTS = [
 {id:1,name:"Nice Peanut Chikki",category:"Kadalai Mittai",price:50,pack:"50 pcs · Packet",emoji:"🥜"},
 {id:2,name:"Peanut Chikki",category:"Kadalai Mittai",price:75,pack:"75 pcs · Packet",emoji:"🍯"},
 {id:3,name:"Peanut Chikki Jar",category:"Chikki",price:150,pack:"50 pcs · Jar",emoji:"🫙"},
 {id:4,name:"Peanut Chikki Cone Jar",category:"Chikki",price:150,pack:"50 pcs · Jar",emoji:"🍬"},
 {id:5,name:"Peanut Chikki Tray",category:"Chikki",price:100,pack:"20 pcs · Tray",emoji:"🍘"},
 {id:6,name:"Ellu Chikki",category:"Ellu Mittai",price:60,pack:"Packet",emoji:"⚫"},
 {id:7,name:"Mysore Pak",category:"Other Sweets",price:80,pack:"Box",emoji:"🟨"},
 {id:8,name:"Kamarkat",category:"Other Sweets",price:50,pack:"Packet",emoji:"🍬"}
];