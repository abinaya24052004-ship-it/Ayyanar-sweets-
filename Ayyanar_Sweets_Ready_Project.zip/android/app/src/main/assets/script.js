// IMPORTANT: Replace with shop WhatsApp number including country code, digits only.
const WHATSAPP_NUMBER = "91XXXXXXXXXX";
let cart = JSON.parse(localStorage.getItem("ayy_cart") || "{}");
let filter = "All";
const money = n => "₹" + Number(n).toLocaleString("en-IN");
function save(){localStorage.setItem("ayy_cart",JSON.stringify(cart));renderCart()}
function renderProducts(){
 const root=document.getElementById("products"); root.innerHTML="";
 PRODUCTS.filter(p=>filter==="All"||p.category===filter).forEach(p=>{
  const el=document.createElement("article"); el.className="product";
  el.innerHTML=`<div class="pic">${p.emoji}</div><div class="info"><h3>${p.name}</h3><p>${p.pack}</p><div class="price">${money(p.price)}</div><button type="button">Add to Cart</button></div>`;
  el.querySelector("button").onclick=()=>{cart[p.id]=(cart[p.id]||0)+1;save()}; root.appendChild(el);
 });
}
function renderCart(){
 let count=0,total=0; const root=document.getElementById("cartItems");root.innerHTML="";
 PRODUCTS.forEach(p=>{const q=Number(cart[p.id]||0);if(q<=0)return;count+=q;total+=q*p.price;
  const el=document.createElement("div");el.className="cartitem";
  el.innerHTML=`<div><b>${p.name}</b><div class="small">${money(p.price)} × ${q}</div></div><div><button type="button" aria-label="decrease">−</button> ${q} <button type="button" aria-label="increase">+</button> <button type="button" aria-label="remove">×</button></div>`;
  const bs=el.querySelectorAll("button");
  bs[0].onclick=()=>{cart[p.id]=q-1;if(cart[p.id]<=0)delete cart[p.id];save()};
  bs[1].onclick=()=>{cart[p.id]=q+1;save()};bs[2].onclick=()=>{delete cart[p.id];save()};root.appendChild(el);
 });
 if(!count)root.innerHTML='<p class="small">Your cart is empty. Add some sweets above.</p>';
 document.getElementById("cartCount").textContent=count;document.getElementById("total").textContent=money(total);
}
document.querySelectorAll("[data-filter]").forEach(b=>b.onclick=()=>{filter=b.dataset.filter;document.querySelectorAll("[data-filter]").forEach(x=>x.classList.toggle("active",x===b));renderProducts()});
document.getElementById("cartJump").onclick=()=>document.getElementById("cart").scrollIntoView();
document.getElementById("placeOrder").onclick=()=>{
 const items=PRODUCTS.filter(p=>Number(cart[p.id]||0)>0).map(p=>`${p.name} x ${cart[p.id]} = ${money(p.price*cart[p.id])}`);
 if(!items.length){alert("Please add products to cart first.");return}
 const name=document.getElementById("customerName").value.trim(),phone=document.getElementById("customerPhone").value.trim(),address=document.getElementById("customerAddress").value.trim();
 if(!name||!phone||!address){alert("Please enter your name, mobile number and delivery address.");return}
 if(!/^[0-9]{10,15}$/.test(phone.replace(/[ +()-]/g,""))){alert("Please enter a valid mobile number.");return}
 if(WHATSAPP_NUMBER.includes("X")){alert("Please set your shop WhatsApp number in script.js before using orders.");return}
 const total=PRODUCTS.reduce((s,p)=>s+(Number(cart[p.id]||0))*p.price,0);
 const message=`Ayyanar Sweets Order\nName: ${name}\nPhone: ${phone}\nAddress: ${address}\n\n${items.join("\n")}\n\nTotal: ${money(total)}\nPayment: ${document.getElementById("payment").value}`;
 window.location.href=`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
};
renderProducts();renderCart();