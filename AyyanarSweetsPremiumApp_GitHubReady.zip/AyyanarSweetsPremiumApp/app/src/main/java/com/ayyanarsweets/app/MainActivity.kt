package com.ayyanarsweets.app

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var bottomNavigation: BottomNavigationView

    private val homeUrl = "https://ayyanar-sweets.web.app/"
    private val whatsappUrl = "https://wa.me/919585846061"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.statusBarColor = getColor(R.color.maroon_dark)
        window.navigationBarColor = getColor(R.color.maroon_dark)

        webView = findViewById(R.id.webView)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        progressBar = findViewById(R.id.progressBar)
        bottomNavigation = findViewById(R.id.bottomNavigation)

        setupWebView()
        setupNavigation()

        findViewById<View>(R.id.whatsappButton).setOnClickListener {
            openWhatsApp()
        }

        swipeRefresh.setOnRefreshListener {
            webView.reload()
        }

        if (savedInstanceState == null) {
            webView.loadUrl(homeUrl)
        } else {
            webView.restoreState(savedInstanceState)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            builtInZoomControls = false
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = false
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
                progressBar.progress = newProgress
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                return handleExternalUrl(request.url.toString())
            }

            @Deprecated("Deprecated in API 24")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                return handleExternalUrl(url)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progressBar.visibility = View.GONE
                swipeRefresh.isRefreshing = false
                injectMobilePolish()
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun handleExternalUrl(url: String): Boolean {
        val lower = url.lowercase()

        if (lower.startsWith("https://wa.me/") ||
            lower.startsWith("whatsapp://") ||
            lower.contains("api.whatsapp.com")) {
            openWhatsApp(url)
            return true
        }

        if (lower.startsWith("tel:") ||
            lower.startsWith("mailto:") ||
            lower.startsWith("upi:")) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this, "No supported app found", Toast.LENGTH_SHORT).show()
            }
            return true
        }

        return false
    }

    private fun setupNavigation() {
        bottomNavigation.setOnItemSelectedListener { item ->
            val target = when (item.itemId) {
                R.id.nav_home -> homeUrl
                R.id.nav_products -> homeUrl + "#products"
                R.id.nav_about -> homeUrl + "#about"
                R.id.nav_contact -> homeUrl + "#contact"
                else -> homeUrl
            }

            webView.loadUrl(target)
            true
        }
    }

    private fun openWhatsApp(url: String = whatsappUrl) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "WhatsApp is not installed", Toast.LENGTH_LONG).show()
        }
    }

    private fun injectMobilePolish() {
        val css = """
            (function() {
                const style = document.createElement('style');
                style.innerHTML = `
                    html { scroll-behavior:smooth; }
                    body { 
                        overflow-x:hidden !important;
                        -webkit-tap-highlight-color:transparent;
                    }
                    img { max-width:100%; }
                    a, button { -webkit-tap-highlight-color:transparent; }
                    @media(max-width:600px) {
                        body { padding-bottom: 72px !important; }
                    }
                `;
                document.head.appendChild(style);
            })();
        """.trimIndent()

        webView.evaluateJavascript(css, null)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        webView.stopLoading()
        webView.clearHistory()
        webView.removeAllViews()
        webView.destroy()
        super.onDestroy()
    }
}
