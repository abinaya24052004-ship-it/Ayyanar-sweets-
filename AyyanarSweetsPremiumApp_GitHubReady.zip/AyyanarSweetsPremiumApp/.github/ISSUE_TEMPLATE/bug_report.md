---
name: Bug report
about: Report a problem in the Ayyanar Sweets app
title: "[BUG] "
labels: bug
---

## What happened?

## Steps to reproduce
1.
2.
3.

## Expected behavior

## Device
- Android version:
- Device model:
- App version:

## Screenshots / logs
