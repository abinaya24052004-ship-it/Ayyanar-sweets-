## What changed?

## Screenshots

## Testing
- [ ] Android Studio build passes
- [ ] App opens correctly
- [ ] Website loads
- [ ] Bottom navigation works
- [ ] WhatsApp button works
- [ ] Back button works

## Notes
